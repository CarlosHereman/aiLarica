// Nome: Abner do Nascimento Santos - RA: 2504154

public interface Frete {

    public double valorFrete(double preco);

    public void impFrete();

}
