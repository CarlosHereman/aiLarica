
import javax.swing.JOptionPane;

// Nome: Abner do Nascimento Santos - RA: 2504154

public class Cliente extends Usuario {

	private long cpf;

	// Construtor default
	public Cliente() {
		cpf = 0;
	}

	// Construtor sobrecarregado
	public Cliente(String nome, long telefone, String endereco, long cpf, String email, String senha) {
		super(nome, telefone, endereco, email, senha);
		this.cpf = cpf;
	}

	// Getters e Setters
	public long getCpf() {
		return cpf;
	}

	public void setCpf(String cpf){
		this.cpf = Long.parseLong(cpf);
	}



	// Sobrescrita
	public void impDados() {
		super.impDados();
		JOptionPane.showMessageDialog(null, "Tipo: CLIENTE", "Cadastro OK", 1);
	}

}
