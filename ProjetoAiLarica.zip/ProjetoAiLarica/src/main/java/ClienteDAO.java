import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAO {

    public boolean cadastrarCliente(Cliente cliente) {
        String sql = "INSERT INTO Cliente (cpf, nome, telefone, endereco, email, senha) VALUES (?, ?, ?, ?, ?, ?)";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, (cliente.getCpf()));
            stmt.setString(2, cliente.getNome());
            stmt.setLong(3, cliente.getTel());
            stmt.setString(4, cliente.getEnd());
            stmt.setString(5, cliente.getEmail());
            stmt.setString(6, cliente.getSenha());

            return stmt.executeUpdate() > 0;  // Retorna true se inseriu com sucesso

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public Cliente consultarClientePorCpf(long cpf) {
        String sql = "SELECT * FROM Cliente WHERE cpf = ?";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, cpf);
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                return new Cliente(
                    rs.getString("cpf"),
                    rs.getLong("nome"),
                    rs.getString("telefone"),
                    rs.getLong("endereco"),
                    rs.getString("email"),
                    rs.getString("senha")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;  // Retorna null se não encontrou
    }

    public boolean removerCliente(long cpf) {
        String sql = "DELETE FROM Cliente WHERE cpf = ?";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setLong(1, cpf);
            return stmt.executeUpdate() > 0;  // Retorna true se removeu com sucesso

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public boolean atualizarCliente(Cliente cliente) {
        String sql = "UPDATE Cliente SET nome = ?, telefone = ?, endereco = ?, email = ? WHERE cpf = ?";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, cliente.getNome());
            stmt.setLong(2, (cliente.getTel()));
            stmt.setString(3, cliente.getEnd());
            stmt.setString(4, cliente.getEmail());
            stmt.setString(5, String.valueOf(cliente.getCpf()));

            return stmt.executeUpdate() > 0;  // Retorna true se atualizou com sucesso

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } 
    }

    public List<Cliente> listarClientes() {
        List<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT * FROM Cliente";

        try (Connection conn = ConexaoBD.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                clientes.add(new Cliente(
                    rs.getString("cpf"),
                    rs.getLong("nome"),
                    rs.getString("telefone"),
                    rs.getLong("endereco"),
                    rs.getString("email"),
                    rs.getString("senha")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clientes;
    }
}
